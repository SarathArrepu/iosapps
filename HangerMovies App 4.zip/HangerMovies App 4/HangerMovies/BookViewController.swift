//
//  BookViewController.swift
//  HangerMovies
//
//  Created by Sai Lavanya Peddinti on 4/30/22.
//

import UIKit

class CellClass: UITableViewCell {
    
}

class BookViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return dataSource.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "Cell", for: indexPath)
        cell.textLabel?.text = dataSource[indexPath.row]
        return cell
    }
    
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        selectedButton.setTitle(dataSource[indexPath.row], for: .normal)
        removeTransparentView()
    }
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 50
    }

    
    @IBOutlet weak var bookingNameOutlet: UITextField!
    
    @IBOutlet weak var btnSelectMovies: UIButton!
    @IBOutlet weak var btnSelectTickets: UIButton!
    
    let transparentView = UIView()
    let tableView = UITableView()
    
    var selectedButton = UIButton()
    
    var dataSource = [String]()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.delegate = self
        tableView.dataSource = self
        tableView.register(CellClass.self, forCellReuseIdentifier: "Cell")
    }
    
    func addTransparentView(frames: CGRect) {
        //trasnaprent view
        let window = UIApplication.shared.keyWindow
        transparentView.frame = window?.frame ?? self.view.frame
        self.view.addSubview(transparentView)
        
        //tableview frame size
        tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        self.view.addSubview(tableView)
        tableView.layer.cornerRadius = 5
        
        //transparentview background color
        transparentView.backgroundColor = UIColor.black.withAlphaComponent(0.9)
        tableView.reloadData()
        
        // for tap operation
        let tapgesture = UITapGestureRecognizer(target: self, action: #selector(removeTransparentView))
        transparentView.addGestureRecognizer(tapgesture)
        transparentView.alpha = 0
        
        //animations code
        UIView.animate(withDuration: 0.2, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseInOut, animations: {
            
            self.transparentView.alpha = 0.2
            
            self.tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height + 5, width: frames.width, height: CGFloat(self.dataSource.count * 50))
        }, completion: nil)
    }
    
    
    //to remove transparent view
    @objc func removeTransparentView() {
        let frames = selectedButton.frame
        UIView.animate(withDuration: 0.4, delay: 0.0, usingSpringWithDamping: 1.0, initialSpringVelocity: 1.0, options: .curveEaseInOut, animations: {
            self.transparentView.alpha = 0
            
            self.tableView.frame = CGRect(x: frames.origin.x, y: frames.origin.y + frames.height, width: frames.width, height: 0)
        }, completion: nil)
    }

    @IBAction func onClickSelectMovies(_ sender: Any) {
        dataSource = ["Akhanda","BheemlaNayak","DjTillu","fivefeetapart","Joker","jumanji","mad max","moonlight","Spider","the dark knight","JaiBhim","Liger","Majili","pushpa","RadheShyam","Dasara","Acharya","SarkarVariPata","boyhood","Aladdin","Twilight","westsidestory"]
        selectedButton = btnSelectMovies
        addTransparentView(frames: btnSelectMovies.frame)
    }
    
    @IBAction func onClickSelectTickets(_ sender: Any) {
        dataSource = ["1", "2","3","4","5","6","7","8","9","10"]
        selectedButton = btnSelectTickets
        addTransparentView(frames: btnSelectTickets.frame)
    }
    
    
    //segue connection to confirmation screen
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        if transition == "confirmSegue"{
            var destination = segue.destination as! ConfirmViewController
             
            destination.bookingname = "Name : \(bookingNameOutlet.text!)"
            }
    }
}

    
   
    
   

