//
//  englishmovie.swift
//  HangerMovies
//
//  Created by Sai Lavanya Peddinti on 4/24/22.
//

import Foundation
import UIKit

struct englishmovie{
    
    let image:UIImage
}

let englishmovies : [englishmovie] = [
    englishmovie(image:UIImage(named: "BatmanvsSpider")!),
    englishmovie(image:UIImage(named: "Aladdin")!),
    englishmovie(image:UIImage(named:"fivefeetapart")!),
    englishmovie(image:UIImage(named: "Joker")!),
    englishmovie(image:UIImage(named:"jumanji")!),
    englishmovie(image:UIImage(named: "GOT")!),
    englishmovie(image:UIImage(named: "LOR")!),
    englishmovie(image:UIImage(named: "Spider")!),
    englishmovie(image:UIImage(named: "the dark knight")!),
    englishmovie(image:UIImage(named: "Twilight")!),
    englishmovie(image:UIImage(named: "westsidestory")!)

]
