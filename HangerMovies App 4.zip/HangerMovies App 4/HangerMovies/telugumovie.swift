//
//  telugumovie.swift
//  HangerMovies
//
//  Created by Sai Lavanya Peddinti on 4/24/22.
//

import Foundation
import UIKit

struct telugumovie{
    let image:UIImage
}

let telugumovies : [telugumovie] = [
    telugumovie(image:UIImage(named: "Akhanda")!),
    telugumovie(image:UIImage(named: "BheemlaNayak")!),
    telugumovie(image:UIImage(named: "DjTillu")!),
    telugumovie(image:UIImage(named: "JaiBhim")!),
    telugumovie(image:UIImage(named: "Liger")!),
    telugumovie(image:UIImage(named: "Majili")!),
    telugumovie(image:UIImage(named: "pushpa")!),
    telugumovie(image:UIImage(named: "RadheShyam")!),
    telugumovie(image:UIImage(named: "Dasara")!),
    telugumovie(image:UIImage(named: "Acharya")!),
    telugumovie(image:UIImage(named: "SarkarVariPata")!)
]
