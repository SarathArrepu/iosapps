//
//  englishmovie.swift
//  HangerMovies
//
//  Created by Sai Lavanya Peddinti on 4/24/22.
//

import Foundation
import UIKit

struct englishmovie{
    let title: String
   let seatsAvailable: String
    let image:UIImage
}

let englishmovies : [englishmovie] = [
    englishmovie(title:"abc",seatsAvailable:"No seats",image:UIImage(named: "boyhood")!),
    englishmovie(title:"abc",seatsAvailable:"100",image:UIImage(named: "Aladdin")!),
    englishmovie(title:"abc",seatsAvailable:"39",image:UIImage(named:"fivefeetapart")!),
    englishmovie(title:"abc",seatsAvailable:"60",image:UIImage(named: "Joker")!),
    englishmovie(title:"abc",seatsAvailable:"28",image:UIImage(named:"jumanji")!),
    englishmovie(title:"abc",seatsAvailable:"69",image:UIImage(named: "mad max")!),
    englishmovie(title:"abc",seatsAvailable:"Almost Booked",image:UIImage(named: "moonlight")!),
    englishmovie(title:"abc",seatsAvailable:"10",image:UIImage(named: "Spider")!),
    englishmovie(title:"abc",seatsAvailable:"01",image:UIImage(named: "the dark knight")!),
    englishmovie(title:"abc",seatsAvailable:"40",image:UIImage(named: "Twilight")!),
    englishmovie(title:"abc",seatsAvailable:"29",image:UIImage(named: "westsidestory")!)

]
