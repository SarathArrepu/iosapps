//
//  telugumovie.swift
//  HangerMovies
//
//  Created by Sai Lavanya Peddinti on 4/24/22.
//

import Foundation
import UIKit

struct telugumovie{
    let title: String
    let seatsAvailable: String
    let image:UIImage
}

let telugumovies : [telugumovie] = [
    telugumovie(title:"abc",seatsAvailable:"30",image:UIImage(named: "Akhanda")!),
    telugumovie(title:"abc",seatsAvailable:"60", image:UIImage(named: "BheemlaNayak")!),
    telugumovie(title:"abc",seatsAvailable:"09",image:UIImage(named: "DjTillu")!),
    telugumovie(title:"abc",seatsAvailable:"30",image:UIImage(named: "JaiBhim")!),
    telugumovie(title:"abc",seatsAvailable:"40",image:UIImage(named: "Liger")!),
    telugumovie(title:"abc",seatsAvailable:"54",image:UIImage(named: "Majili")!),
    telugumovie(title:"abc",seatsAvailable:"67",image:UIImage(named: "pushpa")!),
    telugumovie(title:"abc",seatsAvailable:"42",image:UIImage(named: "RadheShyam")!),
    telugumovie(title:"abc",seatsAvailable:"27",image:UIImage(named: "Dasara")!),
    telugumovie(title:"abc",seatsAvailable:"No seats",image:UIImage(named: "Acharya")!),
    telugumovie(title:"abc",seatsAvailable:"98",image:UIImage(named: "SarkarVariPata")!)
]
