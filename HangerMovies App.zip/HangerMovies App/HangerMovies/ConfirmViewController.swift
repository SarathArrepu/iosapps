//
//  ConfirmViewController.swift
//  HangerMovies
//
//  Created by Sai Lavanya Peddinti on 4/30/22.
//

import UIKit

class ConfirmViewController: UIViewController {

    @IBOutlet weak var qrOutlet: UIImageView!
    
    
   
    @IBOutlet weak var displayLabel: UILabel!
    var tdo = Date()
    
    var bookingname : String = ""
    var filter : CIFilter!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        displayLabel.text! = "Booking Confirmed on \(bookingname) \(tdo)"
        // Do any additional setup after loading the view.
        let data = bookingname.data(using: .ascii,allowLossyConversion: false)
        
            filter = CIFilter(name: "CIQRCodeGenerator")
       
        filter.setValue(data, forKey: "inputMessage")
        let image_obj = UIImage(ciImage: filter.outputImage!)
        
        qrOutlet.image = image_obj
    }
    
    
    

}
